$(document).ready(function(){
 $('.productSection i').hover(function(){
     $('.test').toggle();
 });
});